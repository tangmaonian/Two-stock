/// Plain data models shared by the data layer, chart layer and UI.

class Security {
  const Security({required this.code, required this.name});

  /// Tencent-style code: sh600519, sz000001, sh000001 (index), usAAPL.OQ ...
  final String code;
  final String name;

  bool get isUs => code.startsWith('us');
  bool get isHk => code.startsWith('hk');
  /// Global indices served by Eastmoney, stored as "gl<secid>", e.g.
  /// "gl100.N225". The old "yh<symbol>" form is still accepted for imported
  /// watchlists and is mapped to Eastmoney in the data source.
  bool get isGlobal => code.startsWith('gl') || code.startsWith('yh');
  /// Overseas (non-US/HK) stocks served by Eastmoney, stored as
  /// "os<secid>", e.g. "os176.285A" (Tokyo).
  bool get isOverseas => code.startsWith('os');
  bool get isCn =>
      code.isNotEmpty && !isUs && !isHk && !isGlobal && !isOverseas;

  /// The empty "no overlay" selection (see [kNoOverlay]).
  bool get isNone => code.isEmpty;

  String get marketLabel => isGlobal
      ? '全球指数'
      : (isOverseas ? '海外' : (isUs ? '美股' : (isHk ? '港股' : 'A股')));

  String get shortCode {
    if (isGlobal || isOverseas) {
      final secid = code.substring(2);
      final dot = secid.indexOf('.');
      return dot >= 0 ? secid.substring(dot + 1) : secid;
    }
    var r = code.replaceFirst(RegExp(r'^(sh|sz|bj|hk)'), '');
    if (r.startsWith('us')) r = r.substring(2);
    if (r.startsWith('.')) r = r.substring(1);
    return r;
  }
}

/// One daily bar. [date] is "yyyy-MM-dd" exactly as delivered by the source.
class Bar {
  const Bar(this.date, this.close);
  final String date;
  final double close;
}

class PriceSeries {
  PriceSeries({
    required this.security,
    required this.bars,
    required this.fetchedAt,
    required this.source,
    required this.adjustment,
    required this.decimals,
    this.fromCache = false,
  });

  final Security security;
  final List<Bar> bars;

  /// True when loaded from the on-device store (not fetched just now);
  /// [fetchedAt] is then the time it was saved.
  final bool fromCache;
  final DateTime fetchedAt;
  final String source;

  /// '不复权' or '前复权' - what the prices really are.
  final String adjustment;

  /// Number of decimals to show for this security's prices.
  final int decimals;

  String get lastDate => bars.last.date;
}

/// A live / delayed snapshot price. [asOf] is the timestamp reported by the
/// source (exchange time), NOT the time we fetched it.
/// US Eastern offset from UTC (hours) for a US wall-clock time.
int usEasternOffset(DateTime wall) {
  DateTime nthSunday(int month, int n) {
    var d = DateTime.utc(wall.year, month, 1);
    while (d.weekday != DateTime.sunday) {
      d = d.add(const Duration(days: 1));
    }
    return d.add(Duration(days: 7 * (n - 1)));
  }

  final start = nthSunday(3, 2).add(const Duration(hours: 2));
  final end = nthSunday(11, 1).add(const Duration(hours: 2));
  final w = DateTime.utc(
      wall.year, wall.month, wall.day, wall.hour, wall.minute, wall.second);
  final dst = !w.isBefore(start) && w.isBefore(end);
  return dst ? -4 : -5;
}

class Quote {
  Quote({
    required this.security,
    required this.price,
    required this.prevClose,
    required this.asOf,
    required this.fetchedAt,
    required this.source,
    this.usEastern = false,
  });
  final Security security;
  final bool usEastern; // asOf is US Eastern wall-clock time
  final double price;
  final double? prevClose;
  final String asOf; // "yyyy-MM-dd HH:mm:ss" as reported, may be date only
  final DateTime fetchedAt;
  final String source;

  String get asOfDate => asOf.length >= 10 ? asOf.substring(0, 10) : asOf;

  /// Age of the quote in minutes relative to now, or null if unparseable.
  int? ageMinutes() {
    final t = DateTime.tryParse(asOf.replaceFirst(' ', 'T'));
    if (t == null || asOf.length < 16) return null;
    // China/HK time is UTC+8; US quotes carry US Eastern time.
    final offset = usEastern ? usEasternOffset(t) : 8;
    final utc = DateTime.utc(t.year, t.month, t.day, t.hour, t.minute, t.second)
        .subtract(Duration(hours: offset));
    return DateTime.now().toUtc().difference(utc).inMinutes;
  }
}

class DataException implements Exception {
  DataException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// The blank choice for the overlay slot: nothing is overlaid.
const Security kNoOverlay = Security(code: '', name: '无叠加');

/// Default list shown in the search sheet (code first, name second).
/// Every entry below is verified against Eastmoney in mainland China.
/// US codes no longer need an exchange suffix (.OQ/.N/.AM).
const List<Security> kPresets = [
  // 指数
  Security(code: 'sz399006', name: '创业板指'),
  Security(code: 'sh000688', name: '科创50'),
  Security(code: 'sh000001', name: '上证指数'),
  Security(code: 'hkHSI', name: '恒生指数'),
  Security(code: 'hkHSTECH', name: '恒生科技指数'),
  Security(code: 'us.IXIC', name: '纳斯达克综合'),
  Security(code: 'us.DJI', name: '道琼斯'),
  Security(code: 'gl100.GDAXI', name: '德国DAX'),
  Security(code: 'gl100.FCHI', name: '法国CAC40'),
  Security(code: 'gl100.KS11', name: '韩国综合指数'),
  Security(code: 'gl100.TWII', name: '台湾加权指数'),
  Security(code: 'gl100.N225', name: '日经225（日本）'),
  Security(code: 'os176.285A', name: '铠侠（KIOXIA）'),
  Security(code: 'usSFTBY', name: '软银(ADR)'),
  Security(code: 'gl100.BVSP', name: '巴西圣保罗BOVESPA'),
  Security(code: 'gl100.SENSEX', name: '印度SENSEX'),
  // A股
  Security(code: 'sz300001', name: '特锐德'),
  Security(code: 'sz002902', name: '铭普光磁'),
  Security(code: 'sh600703', name: '三安光电'),
  Security(code: 'sz000338', name: '潍柴动力'),
  Security(code: 'sh601628', name: '中国人寿'),
  Security(code: 'sh600030', name: '中信证券'),
  Security(code: 'sz002594', name: '比亚迪'),
  Security(code: 'sh600031', name: '三一重工'),
  // 美股
  Security(code: 'usCLS', name: '天弘科技'),
  Security(code: 'usGOOG', name: '谷歌-C'),
  Security(code: 'usAVGO', name: '博通'),
  Security(code: 'usNVDA', name: '英伟达'),
  Security(code: 'usMETA', name: 'META'),
  Security(code: 'usAPH', name: '安费诺'),
  Security(code: 'usTEL', name: '泰科电子'),
  Security(code: 'usAAPL', name: '苹果'),
  Security(code: 'usTSM', name: '台积电'),
  Security(code: 'usAA', name: '美国铝业'),
  Security(code: 'usMSFT', name: '微软'),
  Security(code: 'usCRM', name: 'Salesforce'),
  Security(code: 'usVZ', name: 'Verizon'),
  Security(code: 'usQCOM', name: 'QUALCOMM'),
  Security(code: 'usAMZN', name: '亚马逊'),
  Security(code: 'usMRVL', name: 'Marvell'),
  Security(code: 'usSTX', name: 'Seagate'),
  Security(code: 'usMU', name: 'Micron'),
  Security(code: 'usSMCI', name: 'Super Micro'),
  Security(code: 'usCOHR', name: 'Coherent'),
  Security(code: 'usLITE', name: 'Lumentum'),
  Security(code: 'usAAOI', name: 'Applied Optoelectronics'),
  Security(code: 'usNIO', name: '蔚来'),
  Security(code: 'usXPEV', name: '小鹏汽车'),
  Security(code: 'usBIDU', name: '百度'),
  // 港股
  Security(code: 'hk01879', name: '曦智科技-P'),
  Security(code: 'hk02513', name: '智谱'),
  Security(code: 'hk00700', name: '腾讯控股'),
];

/// Default watchlist seeded on first launch (and merged once for existing
/// installs). Codes are Eastmoney-compatible; names come from the user list.
const List<Security> kDefaultWatchlist = [
  Security(code: 'sz399006', name: '创业板指'),
  Security(code: 'sh000688', name: '科创50'),
  Security(code: 'sh000001', name: '上证指数'),
  Security(code: 'hkHSI', name: '恒生指数'),
  Security(code: 'hkHSTECH', name: '恒生科技指数'),
  Security(code: 'us.IXIC', name: '纳斯达克综合'),
  Security(code: 'us.DJI', name: '道琼斯'),
  Security(code: 'gl100.GDAXI', name: '德国DAX'),
  Security(code: 'gl100.FCHI', name: '法国CAC40'),
  Security(code: 'gl100.KS11', name: '韩国综合指数'),
  Security(code: 'gl100.TWII', name: '台湾加权指数'),
  Security(code: 'gl100.N225', name: '日经225（日本）'),
  Security(code: 'os176.285A', name: '铠侠（KIOXIA）'),
  Security(code: 'usSFTBY', name: '软银(ADR)'),
  Security(code: 'gl100.BVSP', name: '巴西圣保罗BOVESPA'),
  Security(code: 'gl100.SENSEX', name: '印度SENSEX'),
  Security(code: 'sz300001', name: '特锐德'),
  Security(code: 'sz002902', name: '铭普光磁'),
  Security(code: 'sh600703', name: '三安光电'),
  Security(code: 'sz000338', name: '潍柴动力'),
  Security(code: 'sh601628', name: '中国人寿'),
  Security(code: 'sh600030', name: '中信证券'),
  Security(code: 'sz002594', name: '比亚迪'),
  Security(code: 'sh600031', name: '三一重工'),
  Security(code: 'usCLS', name: '天弘科技'),
  Security(code: 'usGOOG', name: '谷歌-C'),
  Security(code: 'usAVGO', name: '博通'),
  Security(code: 'usNVDA', name: '英伟达'),
  Security(code: 'usMETA', name: 'META'),
  Security(code: 'usAPH', name: '安费诺'),
  Security(code: 'usTEL', name: '泰科电子'),
  Security(code: 'usAAPL', name: '苹果'),
  Security(code: 'usTSM', name: '台积电'),
  Security(code: 'usAA', name: '美国铝业公司'),
  Security(code: 'usMSFT', name: '微软'),
  Security(code: 'usCRM', name: 'Salesforce, Inc.'),
  Security(code: 'usVZ', name: 'Verizon Communications Inc.'),
  Security(code: 'usQCOM', name: 'QUALCOMM Incorporated'),
  Security(code: 'usAMZN', name: 'Amazon.com, Inc.'),
  Security(code: 'usMRVL', name: 'Marvell Technology, Inc.'),
  Security(code: 'usSTX', name: 'Seagate Technology Holdings PLC'),
  Security(code: 'usMU', name: 'Micron Technology, Inc.'),
  Security(code: 'usSMCI', name: 'Super Micro Computer, Inc.'),
  Security(code: 'usCOHR', name: 'Coherent Corp.'),
  Security(code: 'usLITE', name: 'Lumentum Holdings Inc.'),
  Security(code: 'usAAOI', name: 'Applied Optoelectronics, Inc.'),
  Security(code: 'usNIO', name: 'NIO Inc.'),
  Security(code: 'usXPEV', name: 'XPeng Inc.'),
  Security(code: 'usBIDU', name: 'Baidu, Inc.'),
  Security(code: 'hk01879', name: '曦智科技-P'),
  Security(code: 'hk02513', name: '智谱'),
  Security(code: 'hk00700', name: '腾讯控股'),
  Security(code: 'sh600406', name: '国电南瑞'),
  Security(code: 'sh601179', name: '中国西电'),
  Security(code: 'sh688676', name: '金盘科技'),
  Security(code: 'sz300693', name: '盛弘股份'),
  Security(code: 'sz002428', name: '云南锗业'),
  Security(code: 'sh688825', name: '长鑫科技'),
  Security(code: 'sh600519', name: '贵州茅台'),
  Security(code: 'sz002032', name: '苏泊尔'),
  Security(code: 'sz000333', name: '美的集团'),
  Security(code: 'sz000625', name: '长安汽车'),
  Security(code: 'sh601633', name: '长城汽车'),
  Security(code: 'sz000157', name: '中联重科'),
  Security(code: 'sh601012', name: '隆基绿能'),
  Security(code: 'sh601601', name: '中国太保'),
  Security(code: 'sh601318', name: '中国平安'),
  Security(code: 'sz300059', name: '东方财富'),
  Security(code: 'sh601066', name: '中信建投'),
  Security(code: 'sh600036', name: '招商银行'),
  Security(code: 'sh600000', name: '浦发银行'),
  Security(code: 'sh601390', name: '中国中铁'),
  Security(code: 'sh601186', name: '中国铁建'),
  Security(code: 'sh601766', name: '中国中车'),
  Security(code: 'sh601668', name: '中国建筑'),
  Security(code: 'sh601857', name: '中国石油'),
  Security(code: 'sh600028', name: '中国石化'),
  Security(code: 'sz000933', name: '神火股份'),
  Security(code: 'sh600348', name: '华阳股份'),
  Security(code: 'sh600971', name: '恒源煤电'),
  Security(code: 'sz000630', name: '铜陵有色'),
  Security(code: 'sz000751', name: '锌业股份'),
  Security(code: 'sh601600', name: '中国铝业'),
  Security(code: 'sz000762', name: '西藏矿业'),
  Security(code: 'sz002460', name: '赣锋锂业'),
  Security(code: 'sz002466', name: '天齐锂业'),
  Security(code: 'sh603505', name: '金石资源'),
  Security(code: 'sz300618', name: '寒锐钴业'),
  Security(code: 'sh600887', name: '伊利股份'),
  Security(code: 'sh600882', name: '妙可蓝多'),
  Security(code: 'sz002507', name: '涪陵榨菜'),
  Security(code: 'sh600436', name: '片仔癀'),
  Security(code: 'sh600196', name: '复星医药'),
  Security(code: 'sh600511', name: '国药股份'),
  Security(code: 'sh603039', name: '泛微网络'),
  Security(code: 'sz002709', name: '天赐材料'),
  Security(code: 'sz002920', name: '德赛西威'),
  Security(code: 'sz300496', name: '中科创达'),
  Security(code: 'sh603026', name: '石大胜华'),
  Security(code: 'sh603169', name: '兰石重装'),
  Security(code: 'sz002230', name: '科大讯飞'),
  Security(code: 'sh600895', name: '张江高科'),
  Security(code: 'sh600839', name: '四川长虹'),
  Security(code: 'sz002281', name: '光迅科技'),
  Security(code: 'sh600171', name: '上海贝岭'),
  Security(code: 'sz000858', name: '五粮液'),
  Security(code: 'sh600584', name: '长电科技'),
  Security(code: 'sz301308', name: '江波龙'),
  Security(code: 'sz300782', name: '卓胜微'),
  Security(code: 'sh603501', name: '豪威集团'),
  Security(code: 'sh601216', name: '君正集团'),
  Security(code: 'sh603596', name: '伯特利'),
  Security(code: 'sh600699', name: '均胜电子'),
  Security(code: 'sz300552', name: '万集科技'),
  Security(code: 'sz000049', name: '德赛电池'),
  Security(code: 'sh603259', name: '药明康德'),
  Security(code: 'sz002218', name: '拓日新能'),
  Security(code: 'sh600127', name: '金健米业'),
  Security(code: 'sh600598', name: '北大荒'),
  Security(code: 'sz300750', name: '宁德时代'),
  Security(code: 'sz002475', name: '立讯精密'),
  Security(code: 'sz002456', name: '欧菲光'),
  Security(code: 'sz002241', name: '歌尔股份'),
  Security(code: 'sh603160', name: '汇顶科技'),
  Security(code: 'sz002276', name: '万马股份'),
  Security(code: 'sh601231', name: '环旭电子'),
  Security(code: 'sh688981', name: '中芯国际'),
  Security(code: 'sh688187', name: '时代电气'),
  Security(code: 'sz300073', name: '当升科技'),
  Security(code: 'sh600580', name: '卧龙电驱'),
  Security(code: 'sz002881', name: '美格智能'),
  Security(code: 'sh688521', name: '芯原股份'),
  Security(code: 'sh688303', name: '大全能源'),
  Security(code: 'sh603799', name: '华友钴业'),
  Security(code: 'sz300319', name: '麦捷科技'),
  Security(code: 'sz002138', name: '顺络电子'),
  Security(code: 'sz300857', name: '协创数据'),
  Security(code: 'sh603662', name: '柯力传感'),
  Security(code: 'sh603728', name: '鸣志电器'),
  Security(code: 'sh688234', name: '天岳先进'),
  Security(code: 'sh688313', name: '仕佳光子'),
  Security(code: 'sh688195', name: '腾景科技'),
  Security(code: 'sh688012', name: '中微公司'),
  Security(code: 'sh688037', name: '芯源微'),
  Security(code: 'sh688702', name: '盛科通信-U'),
  Security(code: 'sh688027', name: '国盾量子'),
  Security(code: 'sh688256', name: '寒武纪'),
  Security(code: 'sh688498', name: '源杰科技'),
  Security(code: 'sh688017', name: '绿的谐波'),
  Security(code: 'sh688048', name: '长光华芯'),
  Security(code: 'sh688525', name: '佰维存储'),
  Security(code: 'sh688120', name: '华海清科'),
  Security(code: 'sz002371', name: '北方华创'),
  Security(code: 'sh688072', name: '拓荆科技'),
  Security(code: 'sz000917', name: '电广传媒'),
  Security(code: 'sz300476', name: '胜宏科技'),
  Security(code: 'sz301165', name: '锐捷网络'),
  Security(code: 'sz002396', name: '星网锐捷'),
  Security(code: 'hk02097', name: '蜜雪集团'),
  Security(code: 'sh601127', name: '赛力斯'),
  Security(code: 'sh600418', name: '江淮汽车'),
  Security(code: 'sz300474', name: '景嘉微'),
  Security(code: 'sz000400', name: '许继电气'),
  Security(code: 'sz002028', name: '思源电气'),
  Security(code: 'sz300274', name: '阳光电源'),
  Security(code: 'sh600105', name: '永鼎股份'),
  Security(code: 'sz000568', name: '泸州老窖'),
  Security(code: 'sz000062', name: '深圳华强'),
  Security(code: 'sh600550', name: '保变电气'),
  Security(code: 'sh600106', name: '重庆路桥'),
  Security(code: 'sz002222', name: '福晶科技'),
  Security(code: 'sz300394', name: '天孚通信'),
  Security(code: 'sz300620', name: '光库科技'),
  Security(code: 'sz002837', name: '英维克'),
  Security(code: 'sz300502', name: '新易盛'),
  Security(code: 'sz300308', name: '中际旭创'),
  Security(code: 'sz301626', name: '苏州天脉'),
  Security(code: 'sz301205', name: '联特科技'),
  Security(code: 'sh603893', name: '瑞芯微'),
  Security(code: 'sh688400', name: '凌云光'),
  Security(code: 'sh688685', name: '迈信林'),
  Security(code: 'sh688662', name: '富信科技'),
  Security(code: 'sz002747', name: '埃斯顿'),
];


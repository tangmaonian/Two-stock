import 'market_data_source.dart';
import 'models.dart';
import 'tencent_source.dart';
import 'eastmoney_source.dart';

/// Market-aware provider router. Provider selection is internal and never
/// exposed as a user setting.
///
/// Eastmoney (东方财富) is the default and primary source for every market:
/// A-shares, Hong Kong, US stocks and global indices. Tencent Finance is kept
/// only as a fallback for mainland/HK data.
class AutoMarketDataSource implements MarketDataSource {
  final EastmoneyDataSource _em = EastmoneyDataSource();
  final TencentDataSource _tx = TencentDataSource();

  @override
  String get id => 'auto';
  @override
  String get name => '自动';
  @override
  bool get supportsQuote => true;

  /// US stocks, overseas stocks and global indices are served by Eastmoney.
  bool _eastmoneyOnly(Security s) =>
      s.isUs || s.isGlobal || s.isOverseas;

  List<MarketDataSource> _historyProviders(Security s) => _eastmoneyOnly(s)
      ? <MarketDataSource>[_em]
      : <MarketDataSource>[_em, _tx];

  List<MarketDataSource> _quoteProviders(Security s) => _eastmoneyOnly(s)
      ? <MarketDataSource>[_em]
      : <MarketDataSource>[_em, _tx];

  Future<T> _try<T>(
    List<MarketDataSource> providers,
    Future<T> Function(MarketDataSource) call,
    bool Function(T) valid, {
    Duration perProviderTimeout = const Duration(seconds: 24),
  }) async {
    final errors = <String>[];
    for (final p in providers) {
      try {
        final v = await call(p).timeout(perProviderTimeout);
        if (valid(v)) return v;
        errors.add('${p.name}返回空数据');
      } catch (e) {
        errors.add('${p.name}: $e');
      }
    }
    throw DataException(errors.join('；'));
  }

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) => _try(
        _historyProviders(s),
        (p) => p.history(s, adjusted: adjusted),
        (v) =>
            v.bars.isNotEmpty &&
            v.bars.any((b) => b.close > 0 && b.close.isFinite),
        perProviderTimeout: const Duration(seconds: 25),
      );

  @override
  Future<Quote> quote(Security s) => _try(
        _quoteProviders(s),
        (p) => p.quote(s),
        (v) => v.price > 0 && v.price.isFinite,
        perProviderTimeout: const Duration(seconds: 15),
      );

  @override
  Future<List<Security>> search(String query) async {
    try {
      final r = await _em.search(query);
      if (r.isNotEmpty) return r;
    } catch (_) {
      // Fall back to Tencent search.
    }
    return _tx.search(query);
  }
}

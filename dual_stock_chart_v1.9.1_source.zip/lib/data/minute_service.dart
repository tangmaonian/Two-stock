import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:path_provider/path_provider.dart';

import 'http_util.dart';
import 'eastmoney_source.dart';
import 'models.dart';

class MinutePoint {
  const MinutePoint({
    required this.time,
    required this.price,
    required this.average,
    required this.volume,
  });

  /// "HH:MM" in the exchange's local time.
  final String time;
  final double price;

  /// Average price line (volume weighted).
  final double average;

  /// Volume traded in this minute (not cumulative).
  final double volume;
}

class MinuteSeries {
  const MinuteSeries({
    required this.date,
    required this.points,
    this.source = '',
    this.market = 'other',
    this.fromCache = false,
    this.savedAt,
  });

  final String date; // yyyy-MM-dd
  final List<MinutePoint> points;
  final String source;

  /// 'cn' | 'hk' | 'us' | 'other' - decides the trading-session time axis.
  final String market;

  /// True when this is the copy saved on the device (network unavailable).
  final bool fromCache;
  final DateTime? savedAt;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

class _Recent {
  _Recent(this.at, this.series);
  final DateTime at;
  final MinuteSeries series;
}

final Map<String, Future<MinuteSeries>> _inflight = {};
final Map<String, _Recent> _recent = {};

int _active = 0;
final List<Completer<void>> _waiters = [];

Future<T> _gated<T>(Future<T> Function() f) async {
  while (_active >= 3) {
    final c = Completer<void>();
    _waiters.add(c);
    await c.future;
  }
  _active++;
  try {
    return await f();
  } finally {
    _active--;
    if (_waiters.isNotEmpty) _waiters.removeAt(0).complete();
  }
}

/// Intraday (分时) data for [s].
///
/// Eastmoney (东方财富) is the primary source for every market: A-shares,
/// Hong Kong, US stocks and global indices. Tencent is kept as a fallback for
/// mainland/HK data. A successful result is saved on the device; if every
/// provider fails, the saved copy of the last trading day is returned (marked
/// [MinuteSeries.fromCache]). Only when there is nothing saved either does
/// this throw, with the reason of EACH provider in the message.
Future<MinuteSeries> fetchMinute(Security s, {bool force = false}) {
  final key = s.code;
  if (!force) {
    final r = _recent[key];
    if (r != null && DateTime.now().difference(r.at).inSeconds < 20) {
      return Future.value(r.series);
    }
  }
  final running = _inflight[key];
  if (running != null) return running;
  final f = _gated(() => _fetchMinuteNow(s)).whenComplete(() {
    _inflight.remove(key);
  });
  _inflight[key] = f;
  return f;
}

// ---------------------------------------------------------------------------
// Orchestration
// ---------------------------------------------------------------------------

class _Res {
  _Res.ok(MinuteSeries this.series) : error = null;
  _Res.fail(String this.error) : series = null;
  final MinuteSeries? series;
  final String? error;
}

String _short(Object e) {
  final t = e.toString();
  return t.length > 70 ? '${t.substring(0, 70)}…' : t;
}

Future<_Res> _run(String name, Future<MinuteSeries> Function() f, int secs) async {
  try {
    return _Res.ok(await f().timeout(Duration(seconds: secs)));
  } catch (e) {
    return _Res.fail('$name：${_short(e)}');
  }
}

Future<MinuteSeries?> _firstOk(List<Future<_Res>> fs, List<String> errors) {
  if (fs.isEmpty) return Future.value(null);
  final c = Completer<MinuteSeries?>();
  var left = fs.length;
  for (final f in fs) {
    f.then((r) {
      left--;
      final ok = r.series;
      if (ok != null) {
        if (!c.isCompleted) c.complete(ok);
      } else {
        errors.add(r.error ?? '未知错误');
      }
      if (left == 0 && !c.isCompleted) c.complete(null);
    });
  }
  return c.future;
}

String _marketOf(Security s) =>
    s.isUs ? 'us' : (s.isHk ? 'hk' : (s.isCn ? 'cn' : 'other'));

Future<MinuteSeries> _fetchMinuteNow(Security s) async {
  final errors = <String>[];
  MinuteSeries? result;

  // Eastmoney is the default source for every market, including US stocks
  // and global indices.
  try {
    final secids = await EastmoneyDataSource().secidCandidates(s);
    final emErrors = <String>[];
    for (final secid in secids) {
      final em = await _firstOk(
        const [
          'push2delay.eastmoney.com',
          'push2.eastmoney.com',
          'push2his.eastmoney.com',
        ]
            .map((host) => _run('东方财富[$host]',
                () => _eastmoneyMinute(s, secid, host), 7))
            .toList(),
        emErrors,
      );
      if (em != null) {
        result = em;
        break;
      }
    }
    if (result == null) errors.addAll(emErrors);
  } catch (e) {
    errors.add('东方财富：${_short(e)}');
  }

  // Tencent remains a fallback for mainland/HK data (and some US symbols).
  if (result == null) {
    final tx = await _run('腾讯', () => _tencentMinute(s), 8);
    result = tx.series;
    if (result == null) errors.add(tx.error ?? '腾讯无分时数据');
  }
  if (result == null) {
    final mk = await _run('腾讯分钟线', () => _tencentMKline(s), 7);
    result = mk.series;
    if (result == null) errors.add(mk.error ?? '腾讯分钟线无数据');
  }

  if (result != null && result.points.isNotEmpty) {
    _recent[s.code] = _Recent(DateTime.now(), result);
    unawaited(_saveMinute(s, result));
    return result;
  }
  final saved = await loadSavedMinute(s);
  if (saved != null) return saved;
  throw DataException(errors.isEmpty ? '没有取得分时数据' : errors.join('；'));
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const Map<String, String> _txHeaders = {'Referer': 'https://gu.qq.com/'};

dynamic _jsonOf(Uint8List bytes, String who) {
  try {
    return jsonDecode(utf8.decode(bytes, allowMalformed: true));
  } catch (_) {
    throw DataException('$who返回格式无法识别');
  }
}

String _msgOf(dynamic root) {
  if (root is Map && root['msg'] != null && root['msg'].toString().isNotEmpty) {
    return '（${root['msg']}）';
  }
  return '';
}

String _hhmm(String raw) {
  final t = raw.trim();
  if (RegExp(r'^\d{12}$').hasMatch(t)) {
    return '${t.substring(8, 10)}:${t.substring(10, 12)}';
  }
  if (RegExp(r'^\d{4}$').hasMatch(t)) {
    return '${t.substring(0, 2)}:${t.substring(2, 4)}';
  }
  final m = RegExp(r'(\d{1,2}):(\d{2})').firstMatch(t);
  if (m != null) return '${m.group(1)!.padLeft(2, '0')}:${m.group(2)}';
  return t;
}

String _isoDate(String raw) {
  final t = raw.trim();
  if (RegExp(r'^\d{8}').hasMatch(t)) {
    return '${t.substring(0, 4)}-${t.substring(4, 6)}-${t.substring(6, 8)}';
  }
  if (t.length >= 10) return t.substring(0, 10);
  return t;
}

/// Average price from cumulative volume/amount. Volume may be in lots of 100
/// (A-shares) or in shares, so both are tried; if neither is plausible the
/// plain price is used (never a wrong number).
double _avgPrice(double price, double cumVol, double cumAmt) {
  if (cumVol <= 0 || cumAmt <= 0) return price;
  for (final mult in const [1.0, 100.0]) {
    final a = cumAmt / (cumVol * mult);
    if (a > price * 0.5 && a < price * 2) return a;
  }
  return price;
}

// ---------------------------------------------------------------------------
// Provider: Tencent minute/query  (price, cumulative volume, cumulative amount)
// ---------------------------------------------------------------------------

Future<MinuteSeries> _tencentMinute(Security s) async {
  final eps = s.isUs
      ? const ['UsMinute', 'minute']
      : (s.isHk ? const ['hkMinute', 'minute'] : const ['minute']);
  final errors = <String>[];
  final candidates = <Future<_Res>>[];
  for (final ep in eps) {
    for (final host in const ['web.ifzq.gtimg.cn', 'ifzq.gtimg.cn']) {
      candidates.add(_run('腾讯分时[$host/$ep]',
          () => _tencentMinuteAt(s, ep, host), 6));
    }
  }
  final result = await _firstOk(candidates, errors);
  if (result != null) return result;
  throw DataException(errors.join('；').isEmpty ? '腾讯没有分钟数据' : errors.join('；'));
}

Future<MinuteSeries> _tencentMinuteAt(Security s, String ep, String host) async {
  final uri = Uri.https(host, '/appstock/app/$ep/query', {'code': s.code});
  final r = await httpGet(uri, headers: _txHeaders, timeout: const Duration(seconds: 5));
  final root = _jsonOf(r.bodyBytes, '腾讯');
  final data = root is Map ? root['data'] : null;
  if (data is! Map) throw DataException('接口无数据${_msgOf(root)}');
  dynamic node = data[s.code];
  if (node == null && data.isNotEmpty) node = data.values.first;
  final inner = node is Map ? node['data'] : null;
  final raw = inner is Map ? inner['data'] : null;
  final date = inner is Map ? _isoDate(inner['date']?.toString() ?? '') : '';
  if (raw is! List || raw.isEmpty) throw DataException('返回的分时点为空');
  final pts = <MinutePoint>[];
  // Tencent payloads differ by market/endpoint: some provide cumulative
  // volume, others per-minute volume. Detect cumulative series before
  // calculating deltas so per-minute values are not subtracted twice.
  final rawVolumes = <double>[];
  for (final item in raw) {
    final f = item.toString().trim().split(RegExp(r'\s+'));
    if (f.length > 2) rawVolumes.add(double.tryParse(f[2]) ?? 0.0);
  }
  var monotonic = 0;
  for (var i = 1; i < rawVolumes.length; i++) {
    if (rawVolumes[i] >= rawVolumes[i - 1]) monotonic++;
  }
  final cumulative = rawVolumes.length > 3 && monotonic >= (rawVolumes.length - 1) * 0.8;
  var prevCum = 0.0;
  for (final item in raw) {
    final f = item.toString().trim().split(RegExp(r'\s+'));
    if (f.length < 2) continue;
    final price = double.tryParse(f[1]);
    if (price == null || price <= 0) continue;
    final cumVol = f.length > 2 ? (double.tryParse(f[2]) ?? 0.0) : 0.0;
    final cumAmt = f.length > 3 ? (double.tryParse(f[3]) ?? 0.0) : 0.0;
    var vol = cumulative ? cumVol - prevCum : cumVol;
    if (vol < 0 || !vol.isFinite) vol = cumulative ? cumVol : 0.0;
    prevCum = cumVol;
    pts.add(MinutePoint(
      time: _hhmm(f[0]),
      price: price,
      average: _avgPrice(price, cumVol, cumAmt),
      volume: vol,
    ));
  }
  if (pts.isEmpty) throw DataException('分时数据无法解析');
  return MinuteSeries(date: date, points: pts, source: '腾讯', market: _marketOf(s));
}

// ---------------------------------------------------------------------------
// Provider: Eastmoney trends2  (time, open, close, high, low, vol, amt, avg)
// ---------------------------------------------------------------------------

Future<MinuteSeries> _eastmoneyMinute(
    Security s, String secid, String host) async {
  final uri = Uri.https(host, '/api/qt/stock/trends2/get', {
    'secid': secid,
    'fields1': 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13',
    'fields2': 'f51,f52,f53,f54,f55,f56,f57,f58',
    'ndays': '1',
    'iscr': '0',
    'ut': 'fa5fd1943c7b386f172d6893dbfba10b',
  });
  final r = await httpGet(uri,
      headers: const {
        'Referer': 'https://quote.eastmoney.com/',
        'Origin': 'https://quote.eastmoney.com',
        'Accept': '*/*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
      },
      timeout: const Duration(seconds: 7));
  final root = _jsonOf(r.bodyBytes, '东财');
  final data = root is Map ? root['data'] : null;
  final rows = data is Map ? data['trends'] : null;
  if (rows is! List || rows.isEmpty) throw DataException('返回的分时点为空');
  final pts = <MinutePoint>[];
  var date = '';
  for (final row in rows) {
    final f = row.toString().split(',');
    if (f.length < 3) continue;
    final price = double.tryParse(f[2]) ?? double.tryParse(f[1]);
    if (price == null || price <= 0) continue;
    var avg = f.length > 7 ? double.tryParse(f[7]) : null;
    if (avg == null || avg <= price * 0.5 || avg >= price * 2) avg = price;
    final vol = f.length > 5 ? (double.tryParse(f[5]) ?? 0.0) : 0.0;
    final stamp = f[0].trim();
    if (stamp.length >= 10) date = stamp.substring(0, 10);
    pts.add(MinutePoint(time: _hhmm(stamp), price: price, average: avg, volume: vol));
  }
  if (pts.isEmpty) throw DataException('分时数据无法解析');
  return MinuteSeries(date: date, points: pts, source: '东方财富', market: _marketOf(s));
}

// ---------------------------------------------------------------------------
// Fallbacks built from 1/5-minute K-lines (kept to the LAST trading day)
// ---------------------------------------------------------------------------

MinuteSeries _fromBars(
  Security s,
  String source,
  List<List<dynamic>> bars, // [dateIso, hhmm, close, volume]
) {
  if (bars.isEmpty) throw DataException('没有K线数据');
  final lastDate = bars.last[0] as String;
  final pts = <MinutePoint>[];
  var cumVol = 0.0, cumAmt = 0.0;
  for (final b in bars) {
    if (b[0] != lastDate) continue;
    final price = b[2] as double;
    final vol = b[3] as double;
    cumVol += vol;
    cumAmt += price * vol;
    pts.add(MinutePoint(
      time: b[1] as String,
      price: price,
      average: cumVol > 0 ? cumAmt / cumVol : price,
      volume: vol,
    ));
  }
  if (pts.isEmpty) throw DataException('没有K线数据');
  return MinuteSeries(date: lastDate, points: pts, source: source, market: _marketOf(s));
}

Future<MinuteSeries> _tencentMKline(Security s) async {
  Object? last;
  for (final host in const ['web.ifzq.gtimg.cn', 'ifzq.gtimg.cn']) {
    try {
      final uri = Uri.https(host, '/appstock/app/kline/mkline',
          {'param': '${s.code},m1,,320'});
      final r = await httpGet(uri, headers: _txHeaders, timeout: const Duration(seconds: 5));
      return _parseTencentMKline(s, r.bodyBytes);
    } catch (e) {
      last = e;
    }
  }
  throw DataException(last?.toString() ?? '腾讯分钟线无数据');
}

MinuteSeries _parseTencentMKline(Security s, Uint8List bytes) {
  final root = _jsonOf(bytes, '腾讯分钟线');
  final data = root is Map ? root['data'] : null;
  if (data is! Map) throw DataException('接口无数据${_msgOf(root)}');
  dynamic node = data[s.code];
  if (node == null && data.isNotEmpty) node = data.values.first;
  final rows = node is Map ? node['m1'] : null;
  if (rows is! List || rows.isEmpty) throw DataException('返回为空');
  final bars = <List<dynamic>>[];
  for (final row in rows) {
    if (row is! List || row.length < 6) continue;
    final t = row[0].toString();
    final price = double.tryParse(row[2].toString());
    if (t.length < 12 || price == null || price <= 0) continue;
    bars.add([_isoDate(t), _hhmm(t), price, double.tryParse(row[5].toString()) ?? 0.0]);
  }
  return _fromBars(s, '腾讯1分钟线', bars);
}

// ---------------------------------------------------------------------------
// Local copy of the last successful intraday series
// ---------------------------------------------------------------------------

Directory? _minDir;

Future<Directory?> _minuteDir() async {
  if (_minDir != null) return _minDir;
  try {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/minute');
    if (!await d.exists()) await d.create(recursive: true);
    _minDir = d;
    return d;
  } catch (_) {
    return null;
  }
}

String _fname(String code) =>
    '${code.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_')}.json';

Future<void> _saveMinute(Security s, MinuteSeries m) async {
  if (m.points.length < 5) return;
  try {
    final d = await _minuteDir();
    if (d == null) return;
    await File('${d.path}/${_fname(s.code)}').writeAsString(jsonEncode({
      'v': 1,
      'date': m.date,
      'source': m.source,
      'market': m.market,
      'savedAt': DateTime.now().toIso8601String(),
      'points': m.points.map((p) => [p.time, p.price, p.average, p.volume]).toList(),
    }));
  } catch (_) {}
}

/// The copy saved on the device, or null.
Future<MinuteSeries?> loadSavedMinute(Security s) async {
  try {
    final d = await _minuteDir();
    if (d == null) return null;
    final f = File('${d.path}/${_fname(s.code)}');
    if (!await f.exists()) return null;
    final j = jsonDecode(await f.readAsString());
    if (j is! Map || j['points'] is! List) return null;
    final pts = <MinutePoint>[];
    for (final p in j['points'] as List) {
      if (p is List && p.length == 4 && p[0] is String && p[1] is num && p[2] is num && p[3] is num) {
        pts.add(MinutePoint(
          time: p[0] as String,
          price: (p[1] as num).toDouble(),
          average: (p[2] as num).toDouble(),
          volume: (p[3] as num).toDouble(),
        ));
      }
    }
    if (pts.isEmpty) return null;
    return MinuteSeries(
      date: j['date']?.toString() ?? '',
      points: pts,
      source: j['source']?.toString() ?? '本地',
      market: j['market']?.toString() ?? 'other',
      fromCache: true,
      savedAt: DateTime.tryParse(j['savedAt']?.toString() ?? ''),
    );
  } catch (_) {
    return null;
  }
}

/// Plain data models shared by the data layer, chart layer and UI.

class Security {
  const Security({required this.code, required this.name});

  /// Tencent-style code: sh600519, sz000001, sh000001 (index), usAAPL.OQ ...
  final String code;
  final String name;

  bool get isUs => code.startsWith('us');
  bool get isHk => code.startsWith('hk');
  /// Global indices served by Eastmoney, stored as "gl<secid>", e.g.
  /// "gl100.N225". The old "yh<symbol>" form is still accepted for imported
  /// watchlists and is mapped to Eastmoney in the data source.
  bool get isGlobal => code.startsWith('gl') || code.startsWith('yh');
  /// Overseas (non-US/HK) stocks served by Eastmoney, stored as
  /// "os<secid>", e.g. "os176.285A" (Tokyo).
  bool get isOverseas => code.startsWith('os');
  bool get isCn =>
      code.isNotEmpty && !isUs && !isHk && !isGlobal && !isOverseas;

  /// The empty "no overlay" selection (see [kNoOverlay]).
  bool get isNone => code.isEmpty;

  String get marketLabel => isGlobal
      ? '全球指数'
      : (isOverseas ? '海外' : (isUs ? '美股' : (isHk ? '港股' : 'A股')));

  String get shortCode {
    if (isGlobal || isOverseas) {
      final secid = code.substring(2);
      final dot = secid.indexOf('.');
      return dot >= 0 ? secid.substring(dot + 1) : secid;
    }
    var r = code.replaceFirst(RegExp(r'^(sh|sz|bj|hk)'), '');
    if (r.startsWith('us')) r = r.substring(2);
    if (r.startsWith('.')) r = r.substring(1);
    return r;
  }
}

/// One daily bar. [date] is "yyyy-MM-dd" exactly as delivered by the source.
class Bar {
  const Bar(this.date, this.close);
  final String date;
  final double close;
}

class PriceSeries {
  PriceSeries({
    required this.security,
    required this.bars,
    required this.fetchedAt,
    required this.source,
    required this.adjustment,
    required this.decimals,
    this.fromCache = false,
  });

  final Security security;
  final List<Bar> bars;

  /// True when loaded from the on-device store (not fetched just now);
  /// [fetchedAt] is then the time it was saved.
  final bool fromCache;
  final DateTime fetchedAt;
  final String source;

  /// '不复权' or '前复权' - what the prices really are.
  final String adjustment;

  /// Number of decimals to show for this security's prices.
  final int decimals;

  String get lastDate => bars.last.date;
}

/// A live / delayed snapshot price. [asOf] is the timestamp reported by the
/// source (exchange time), NOT the time we fetched it.
/// US Eastern offset from UTC (hours) for a US wall-clock time.
int usEasternOffset(DateTime wall) {
  DateTime nthSunday(int month, int n) {
    var d = DateTime.utc(wall.year, month, 1);
    while (d.weekday != DateTime.sunday) {
      d = d.add(const Duration(days: 1));
    }
    return d.add(Duration(days: 7 * (n - 1)));
  }

  final start = nthSunday(3, 2).add(const Duration(hours: 2));
  final end = nthSunday(11, 1).add(const Duration(hours: 2));
  final w = DateTime.utc(
      wall.year, wall.month, wall.day, wall.hour, wall.minute, wall.second);
  final dst = !w.isBefore(start) && w.isBefore(end);
  return dst ? -4 : -5;
}

class Quote {
  Quote({
    required this.security,
    required this.price,
    required this.prevClose,
    required this.asOf,
    required this.fetchedAt,
    required this.source,
    this.usEastern = false,
  });
  final Security security;
  final bool usEastern; // asOf is US Eastern wall-clock time
  final double price;
  final double? prevClose;
  final String asOf; // "yyyy-MM-dd HH:mm:ss" as reported, may be date only
  final DateTime fetchedAt;
  final String source;

  String get asOfDate => asOf.length >= 10 ? asOf.substring(0, 10) : asOf;

  /// Age of the quote in minutes relative to now, or null if unparseable.
  int? ageMinutes() {
    final t = DateTime.tryParse(asOf.replaceFirst(' ', 'T'));
    if (t == null || asOf.length < 16) return null;
    // China/HK time is UTC+8; US quotes carry US Eastern time.
    final offset = usEastern ? usEasternOffset(t) : 8;
    final utc = DateTime.utc(t.year, t.month, t.day, t.hour, t.minute, t.second)
        .subtract(Duration(hours: offset));
    return DateTime.now().toUtc().difference(utc).inMinutes;
  }
}

class DataException implements Exception {
  DataException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// The blank choice for the overlay slot: nothing is overlaid.
const Security kNoOverlay = Security(code: '', name: '无叠加');

/// Default list shown in the search sheet (code first, name second).
/// Every entry below is verified against Eastmoney in mainland China.
/// US codes no longer need an exchange suffix (.OQ/.N/.AM).
const List<Security> kPresets = [
  // 指数
  Security(code: 'sz399006', name: '创业板指'),
  Security(code: 'sh000688', name: '科创50'),
  Security(code: 'sh000001', name: '上证指数'),
  Security(code: 'hkHSI', name: '恒生指数'),
  Security(code: 'hkHSTECH', name: '恒生科技指数'),
  Security(code: 'us.IXIC', name: '纳斯达克综合'),
  Security(code: 'us.DJI', name: '道琼斯'),
  Security(code: 'gl100.GDAXI', name: '德国DAX'),
  Security(code: 'gl100.FCHI', name: '法国CAC40'),
  Security(code: 'gl100.KS11', name: '韩国综合指数'),
  Security(code: 'gl100.TWII', name: '台湾加权指数'),
  Security(code: 'gl100.N225', name: '日经225（日本）'),
  Security(code: 'os176.285A', name: '铠侠（KIOXIA）'),
  Security(code: 'usSFTBY', name: '软银(ADR)'),
  Security(code: 'gl100.BVSP', name: '巴西圣保罗BOVESPA'),
  Security(code: 'gl100.SENSEX', name: '印度SENSEX'),
  // A股
  Security(code: 'sz300001', name: '特锐德'),
  Security(code: 'sz002902', name: '铭普光磁'),
  Security(code: 'sh600703', name: '三安光电'),
  Security(code: 'sz000338', name: '潍柴动力'),
  Security(code: 'sh601628', name: '中国人寿'),
  Security(code: 'sh600030', name: '中信证券'),
  Security(code: 'sz002594', name: '比亚迪'),
  Security(code: 'sh600031', name: '三一重工'),
  // 美股
  Security(code: 'usCLS', name: '天弘科技'),
  Security(code: 'usGOOG', name: '谷歌-C'),
  Security(code: 'usAVGO', name: '博通'),
  Security(code: 'usNVDA', name: '英伟达'),
  Security(code: 'usMETA', name: 'META'),
  Security(code: 'usAPH', name: '安费诺'),
  Security(code: 'usTEL', name: '泰科电子'),
  Security(code: 'usAAPL', name: '苹果'),
  Security(code: 'usTSM', name: '台积电'),
  Security(code: 'usAA', name: '美国铝业'),
  Security(code: 'usMSFT', name: '微软'),
  Security(code: 'usCRM', name: 'Salesforce'),
  Security(code: 'usVZ', name: 'Verizon'),
  Security(code: 'usQCOM', name: 'QUALCOMM'),
  Security(code: 'usAMZN', name: '亚马逊'),
  Security(code: 'usMRVL', name: 'Marvell'),
  Security(code: 'usSTX', name: 'Seagate'),
  Security(code: 'usMU', name: 'Micron'),
  Security(code: 'usSMCI', name: 'Super Micro'),
  Security(code: 'usCOHR', name: 'Coherent'),
  Security(code: 'usLITE', name: 'Lumentum'),
  Security(code: 'usAAOI', name: 'Applied Optoelectronics'),
  Security(code: 'usNIO', name: '蔚来'),
  Security(code: 'usXPEV', name: '小鹏汽车'),
  Security(code: 'usBIDU', name: '百度'),
  // 港股
  Security(code: 'hk01879', name: '曦智科技-P'),
  Security(code: 'hk02513', name: '智谱'),
  Security(code: 'hk00700', name: '腾讯控股'),
];

import 'models.dart';

/// Abstraction over a market-data provider. The chart and UI only depend on
/// this interface, so providers can be swapped from the settings menu.
abstract class MarketDataSource {
  /// Short id used in the picker.
  String get id;
  String get name;

  /// Whether [quote] is implemented (a snapshot price of today).
  bool get supportsQuote;

  Future<List<Security>> search(String query);

  /// Daily history, oldest first. Throws [DataException] on any failure.
  Future<PriceSeries> history(Security security, {required bool adjusted});

  /// Latest snapshot price. Throws [DataException] if unsupported/failed.
  Future<Quote> quote(Security security);
}

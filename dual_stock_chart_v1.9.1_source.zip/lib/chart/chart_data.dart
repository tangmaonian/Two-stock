import 'dart:math' as math;

import '../data/models.dart';

/// Two series aligned on the union of their trading dates.
/// A null value means "no trading data on that date" - never filled in.
class ChartData {
  ChartData._(this.dates, this.main, this.over, this._index);

  factory ChartData.empty() => ChartData._([], [], [], {});

  factory ChartData.align(PriceSeries? a, PriceSeries? b) {
    final set = <String>{};
    if (a != null) set.addAll(a.bars.map((e) => e.date));
    if (b != null) set.addAll(b.bars.map((e) => e.date));
    final dates = set.toList()..sort();
    final index = <String, int>{};
    for (var i = 0; i < dates.length; i++) {
      index[dates[i]] = i;
    }
    List<double?> fill(PriceSeries? s) {
      final out = List<double?>.filled(dates.length, null);
      if (s != null) {
        for (final bar in s.bars) {
          out[index[bar.date]!] = bar.close;
        }
      }
      return out;
    }

    return ChartData._(dates, fill(a), fill(b), index);
  }

  final List<String> dates;
  final List<double?> main;
  final List<double?> over;
  final Map<String, int> _index;

  int get length => dates.length;

  int indexOf(String? date) => date == null ? -1 : (_index[date] ?? -1);

  /// Base index for normalisation: the cursor date if both series have data
  /// there, otherwise the first visible date where both have data. -1 if none.
  int commonBase(int lo, int hi, int cursor) {
    if (cursor >= 0 && main[cursor] != null && over[cursor] != null) {
      return cursor;
    }
    for (var i = lo; i <= hi; i++) {
      if (main[i] != null && over[i] != null) return i;
    }
    return -1;
  }
}

/// "Nice" axis tick values between [lo] and [hi].
List<double> niceTicks(double lo, double hi, {int target = 5}) {
  final range = hi - lo;
  if (range <= 0) return [lo];
  final raw = range / target;
  final mag = math.pow(10, (math.log(raw) / math.ln10).floor()).toDouble();
  final n = raw / mag;
  final step = (n < 1.5 ? 1 : n < 3 ? 2 : n < 7 ? 5 : 10) * mag;
  final out = <double>[];
  var t = (lo / step).ceil() * step;
  while (t <= hi + step * 1e-9) {
    out.add(t);
    t += step;
  }
  return out;
}

/// Decimals needed to print multiples of [step] exactly.
int decimalsForStep(double step) {
  if (step >= 1) return 0;
  return math.max(0, (-(math.log(step) / math.ln10) - 1e-9).ceil());
}

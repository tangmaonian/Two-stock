import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'http_util.dart';
import 'market_data_source.dart';
import 'models.dart';
import 'tencent_source.dart';

/// Eastmoney (东方财富) is the single primary data source for A-shares,
/// Hong Kong, US stocks and global indices. It also provides search.
///
/// secid formats:
///   1.600519 / 0.000001    Shanghai / Shenzhen-Beijing A-shares
///   116.00700              Hong Kong stocks
///   105.AAPL 106.BABA 107.SPY   US stocks (NASDAQ / NYSE / AMEX)
///   100.HSI 124.HSTECH 100.SPX 100.NDX 100.DJIA 100.N225 ...  indices
class EastmoneyDataSource implements MarketDataSource {
  static const int _targetBars = 2500;
  static const String _ut = 'fa5fd1943c7b386f172d6893dbfba10b';
  static const String _searchToken = 'D43BF722C8E33BDC906FB84D85E326E8';
  static const List<String> _klineHosts = [
    'push2his.eastmoney.com',
    'push2.eastmoney.com',
    'push2delay.eastmoney.com',
  ];
  static const List<String> _quoteHosts = [
    'push2.eastmoney.com',
    'push2delay.eastmoney.com',
  ];
  static const Map<String, String> _headers = {
    'Referer': 'https://quote.eastmoney.com/',
    'Origin': 'https://quote.eastmoney.com',
    'Accept': '*/*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
  };

  final TencentDataSource _searcher = TencentDataSource();

  /// Cache of US symbol -> secid, and of all resolved candidates.
  static final Map<String, String> _usSecidCache = {};
  static final Map<String, Future<List<String>>> _candidateFutures = {};

  /// Old Yahoo-style index symbols kept for existing watchlists.
  static const Map<String, String> _legacyIndex = {
    'yh^GSPC': '100.SPX',
    'yh^IXIC': '100.NDX',
    'yh^DJI': '100.DJIA',
    'yh^HSI': '100.HSI',
    'yh^HSTECH': '124.HSTECH',
    'yh^N225': '100.N225',
    'yh^TWII': '100.TWII',
    'yh^KS11': '100.KS11',
    'yh^GDAXI': '100.GDAXI',
    'yh^FCHI': '100.FCHI',
    'yh^BSESN': '100.SENSEX',
    'yhRTSI.ME': '100.RTS',
    'yh^SET.BK': '100.SET',
    'yh^VNINDEX.VN': '100.VNINDEX',
    'yh^BVSP': '100.BVSP',
  };

  @override
  String get id => 'eastmoney';
  @override
  String get name => '东方财富';
  @override
  bool get supportsQuote => true;

  // ---------------------------------------------------------------------------
  // secid resolution
  // ---------------------------------------------------------------------------

  /// Returns a fixed secid when the code is unambiguous, otherwise null.
  String? _directSecid(Security s) {
    final c = s.code;
    if (c.isEmpty) return null;
    if (c.startsWith('gl')) {
      final rest = c.substring(2);
      return rest.isEmpty ? null : rest;
    }
    final legacy = _legacyIndex[c];
    if (legacy != null) return legacy;
    if (c.startsWith('hk')) {
      if (c == 'hkHSI') return '100.HSI';
      if (c == 'hkHSTECH') return '124.HSTECH';
      final d = c.substring(2);
      if (RegExp(r'^\d{5}$').hasMatch(d)) return '116.$d';
      return null;
    }
    if (c.startsWith('us')) {
      switch (c.substring(2).toUpperCase()) {
        case '.INX':
        case 'INX':
        case 'SPX':
          return '100.SPX';
        case '.IXIC':
        case 'IXIC':
          return '100.NDX';
        case '.DJI':
        case 'DJI':
          return '100.DJIA';
        case '.NDX':
        case 'NDX':
          return '100.NDX100';
      }
      return null;
    }
    if (c.startsWith('sh')) return '1.${c.substring(2)}';
    if (c.startsWith('sz') || c.startsWith('bj')) return '0.${c.substring(2)}';
    return null;
  }

  String _usSymbol(Security s) => s.code.substring(2).toUpperCase();

  /// All secids worth trying for [s]. US symbols are resolved through
  /// Eastmoney search first, then by trying the three US market numbers.
  Future<List<String>> secidCandidates(Security s) {
    final key = s.code;
    return _candidateFutures.putIfAbsent(key, () async {
      try {
        final direct = _directSecid(s);
        if (direct != null) return <String>[direct];
        if (s.isUs) {
          final sym = _usSymbol(s);
          final cached = _usSecidCache[sym];
          if (cached != null) return <String>[cached];
          final qid = await _lookupUsSecid(sym);
          if (qid != null) {
            _usSecidCache[sym] = qid;
            return <String>[qid];
          }
          final alt = sym.replaceAll('.', '_');
          return <String>['105.$alt', '106.$alt', '107.$alt'];
        }
        throw DataException('东方财富暂不支持该代码（${s.code}）');
      } catch (e) {
        _candidateFutures.remove(key);
        rethrow;
      }
    });
  }

  Future<String?> _lookupUsSecid(String symbol) async {
    try {
      final uri = Uri.https('searchapi.eastmoney.com', '/api/suggest/get', {
        'input': symbol,
        'type': '14',
        'token': _searchToken,
        'count': '20',
      });
      final r = await httpGet(uri,
          headers: _headers,
          timeout: const Duration(seconds: 8),
          maxAttempts: 1);
      final j = jsonDecode(utf8.decode(r.bodyBytes, allowMalformed: true));
      final table = (j is Map) ? j['QuotationCodeTable'] : null;
      final data = (table is Map) ? table['Data'] : null;
      if (data is! List) return null;
      final want = symbol.toUpperCase().replaceAll('.', '_');
      for (final it in data) {
        if (it is! Map) continue;
        if (it['SecurityTypeName']?.toString() != '美股') continue;
        final code =
            it['Code']?.toString().toUpperCase().replaceAll('.', '_') ?? '';
        if (code != want) continue;
        final qid = it['QuoteID']?.toString();
        if (qid != null && qid.contains('.')) return qid;
      }
    } catch (_) {
      // Fall through to the 105/106/107 attempts.
    }
    return null;
  }

  // ---------------------------------------------------------------------------
  // Search
  // ---------------------------------------------------------------------------

  @override
  Future<List<Security>> search(String query) async {
    try {
      final list = await _searchEastmoney(query);
      if (list.isNotEmpty) return list;
    } catch (_) {
      // Fall back to Tencent below.
    }
    final all = await _searcher.search(query);
    return all.where((s) => s.isCn || s.isHk).toList();
  }

  Future<List<Security>> _searchEastmoney(String query) async {
    final uri = Uri.https('searchapi.eastmoney.com', '/api/suggest/get', {
      'input': query,
      'type': '14',
      'token': _searchToken,
      'count': '20',
    });
    final r = await httpGet(uri,
        headers: _headers,
        timeout: const Duration(seconds: 10),
        maxAttempts: 2);
    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes, allowMalformed: true));
    } on FormatException {
      throw DataException('东方财富搜索结果格式无法识别');
    }
    final table = (j is Map) ? j['QuotationCodeTable'] : null;
    final data = (table is Map) ? table['Data'] : null;
    if (data is! List) return <Security>[];
    final out = <Security>[];
    final seen = <String>{};
    for (final it in data) {
      if (it is! Map) continue;
      final type = it['SecurityTypeName']?.toString() ?? '';
      final rawCode = it['Code']?.toString() ?? '';
      final name = it['Name']?.toString() ?? rawCode;
      final mkt = it['MktNum']?.toString() ?? '';
      final quoteId = it['QuoteID']?.toString() ?? '';
      String? code;
      switch (type) {
        case '沪A':
          code = 'sh$rawCode';
          break;
        case '深A':
          code = 'sz$rawCode';
          break;
        case '京A':
          code = 'bj$rawCode';
          break;
        case '港股':
          code = 'hk$rawCode';
          break;
        case '美股':
          code = 'us${rawCode.toUpperCase()}';
          break;
        case '指数':
          if ((mkt == '100' || mkt == '124') && quoteId.contains('.')) {
            code = 'gl$quoteId';
          } else if (mkt == '1') {
            code = 'sh$rawCode';
          } else if (mkt == '0') {
            code = 'sz$rawCode';
          }
          break;
      }
      if (code == null || code.isEmpty) continue;
      if (seen.add(code)) {
        out.add(Security(code: code, name: name.isEmpty ? rawCode : name));
      }
      if (out.length >= 20) break;
    }
    return out;
  }

  // ---------------------------------------------------------------------------
  // Daily history
  // ---------------------------------------------------------------------------

  Map<String, String> _klineParams(String secid,
      {required bool adjusted, required int limit, required bool webStyle}) {
    final now = DateTime.now();
    final beg = '${now.year - 12}0101';
    final params = <String, String>{
      'secid': secid,
      'fields1': 'f1,f2,f3,f4,f5,f6',
      'fields2': webStyle
          ? 'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61'
          : 'f51,f52,f53,f54,f55,f56,f57',
      'klt': '101',
      'fqt': adjusted ? '1' : '0',
      'beg': beg,
      'end': '20500101',
      'lmt': '$limit',
      'ut': _ut,
    };
    if (webStyle) {
      params['smplmt'] = '460';
      params['_'] = '${DateTime.now().millisecondsSinceEpoch}';
    }
    return params;
  }

  Future<PriceSeries> _getKlineFromHost(
      Security s, String host, Map<String, String> params,
      {required bool adjusted}) async {
    try {
      final r = await httpGet(
        Uri.https(host, '/api/qt/stock/kline/get', params),
        headers: _headers,
        timeout: const Duration(seconds: 18),
        maxAttempts: 2,
      );
      return _parseKlineResponse(s, r, adjusted: adjusted);
    } catch (e) {
      throw DataException('$host ${e is DataException ? e.message : e}');
    }
  }

  PriceSeries _parseKlineResponse(Security s, http.Response r,
      {required bool adjusted}) {
    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes, allowMalformed: true));
    } on FormatException {
      throw DataException('数据格式无法识别');
    }
    if (j is Map &&
        j['rc'] is num &&
        (j['rc'] as num) != 0 &&
        j['data'] == null) {
      throw DataException('接口返回异常（rc=${j['rc']}）');
    }
    final data = (j is Map) ? j['data'] : null;
    final lines = (data is Map) ? data['klines'] : null;
    if (lines is! List || lines.isEmpty) {
      throw DataException('没有该代码的日线行情（${s.code}）');
    }
    // each line: "date,open,close,high,low,volume,amount"
    final byDate = <String, Bar>{};
    var dec = 2;
    for (final line in lines) {
      final p = line.toString().split(',');
      if (p.length < 3) continue;
      final dateRaw = p[0].trim();
      if (dateRaw.length < 10) continue;
      final date = dateRaw.substring(0, 10);
      if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(date)) continue;
      final closeStr = p[2].trim();
      final c = double.tryParse(closeStr);
      if (c == null || !c.isFinite || c <= 0) continue;
      final d = decimalsOf(closeStr);
      if (d > dec) dec = d;
      byDate[date] = Bar(date, c);
    }
    if (byDate.isEmpty) throw DataException('日线数据为空或无法解析');
    final bars = byDate.values.toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    final trimmed = bars.length > _targetBars
        ? bars.sublist(bars.length - _targetBars)
        : bars;
    return PriceSeries(
      security: s,
      bars: trimmed,
      fetchedAt: DateTime.now(),
      source: name,
      adjustment: adjusted ? '前复权' : '不复权',
      decimals: dec > 4 ? 4 : dec,
    );
  }

  /// 三个东方财富集群同时请求并校验解析结果，谁先返回有效日线序列就用谁。
  Future<PriceSeries> _klineAnyHost(Security s, Map<String, String> params,
      {required bool adjusted}) {
    final c = Completer<PriceSeries>();
    final errs = <String>[];
    var failed = 0;
    for (final host in _klineHosts) {
      _getKlineFromHost(s, host, params, adjusted: adjusted).then((series) {
        if (!c.isCompleted) c.complete(series);
      }, onError: (Object e) {
        errs.add('$e');
        failed++;
        if (failed == _klineHosts.length && !c.isCompleted) {
          c.completeError(DataException(errs.join(' / ')));
        }
      });
    }
    return c.future;
  }

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) async {
    final candidates = await secidCandidates(s);
    final errs = <String>[];
    for (final secid in candidates) {
      for (final webStyle in const [false, true]) {
        try {
          final params = _klineParams(secid,
              adjusted: adjusted, limit: _targetBars, webStyle: webStyle);
          return await _klineAnyHost(s, params, adjusted: adjusted);
        } on DataException catch (e) {
          if (e.message.contains('暂不支持') || e.message.contains('仅支持')) {
            rethrow;
          }
          errs.add(e.message);
        } catch (e) {
          errs.add('$e');
        }
      }
    }
    throw DataException(errs.isEmpty ? '东方财富日线请求失败' : errs.first);
  }

  // ---------------------------------------------------------------------------
  // Snapshot quote
  // ---------------------------------------------------------------------------

  /// push2 stock/get: f43=latest price, f60=prev close, f86=quote unix time.
  @override
  Future<Quote> quote(Security s) async {
    final candidates = await secidCandidates(s);
    Object? lastErr;
    for (final secid in candidates) {
      for (final host in _quoteHosts) {
        try {
          final uri = Uri.https(host, '/api/qt/stock/get', {
            'secid': secid,
            'fields': 'f43,f58,f60,f86',
            'fltt': '2',
            'invt': '2',
            'ut': _ut,
          });
          final r = await httpGet(uri,
              headers: _headers,
              timeout: const Duration(seconds: 12),
              maxAttempts: 2);
          return _parseQuote(s, r);
        } catch (e) {
          lastErr = e;
        }
      }
    }
    throw lastErr is DataException
        ? lastErr
        : DataException('${lastErr ?? '东方财富实时报价失败'}');
  }

  Quote _parseQuote(Security s, http.Response r) {
    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes, allowMalformed: true));
    } on FormatException {
      throw DataException('东方财富实时报价格式无法识别');
    }
    final d = (j is Map) ? j['data'] : null;
    if (d is! Map) throw DataException('东方财富没有该代码的实时报价');
    final price = (d['f43'] is num) ? (d['f43'] as num).toDouble() : null;
    if (price == null || price <= 0) {
      throw DataException('东方财富实时报价为空（可能未开盘或停牌）');
    }
    final ts = d['f86'];
    if (ts is! num || ts <= 0) {
      throw DataException('东方财富实时报价没有时间戳，无法判断新旧');
    }
    // f86 is a Unix (UTC) timestamp; show it in China time (UTC+8).
    final t = DateTime.fromMillisecondsSinceEpoch(ts.toInt() * 1000, isUtc: true)
        .add(const Duration(hours: 8));
    String two(int v) => v.toString().padLeft(2, '0');
    final asOf = '${t.year}-${two(t.month)}-${two(t.day)} '
        '${two(t.hour)}:${two(t.minute)}:${two(t.second)}';
    return Quote(
      security: s,
      price: price,
      prevClose: (d['f60'] is num) ? (d['f60'] as num).toDouble() : null,
      asOf: asOf,
      fetchedAt: DateTime.now(),
      source: name,
    );
  }
}

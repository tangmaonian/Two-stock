import 'models.dart';

/// Text format: one security per line, "code,name". Lines starting with # are
/// comments. On import a bare code is enough (600519, 00700, AAPL ...).
String exportWatchlist(List<Security> list) {
  final b = StringBuffer('# 双线股票分析 自选股（每行：代码,名称）\n');
  for (final s in list) {
    b.writeln('${s.code},${s.name}');
  }
  return b.toString();
}

class ParseResult {
  ParseResult(this.items, this.skipped);
  final List<Security> items;
  final int skipped;
}

String? _normalizeCode(String raw) {
  final t = raw.trim();
  if (t.isEmpty) return null;
  final lower = t.toLowerCase();
  if (RegExp(r'^(sh|sz|bj)\d{6}$').hasMatch(lower)) return lower;
  if (RegExp(r'^\d{6}$').hasMatch(t)) {
    final c = t[0];
    if ('659'.contains(c)) return 'sh$t';
    if ('0123'.contains(c)) return 'sz$t';
    if ('48'.contains(c)) return 'bj$t';
    return null;
  }
  if (RegExp(r'^hk\d{5}$').hasMatch(lower)) return lower;
  if (RegExp(r'^\d{5}$').hasMatch(t)) return 'hk$t';
  if (lower.startsWith('hk') && RegExp(r'^[A-Za-z]+$').hasMatch(t.substring(2))) {
    return 'hk${t.substring(2).toUpperCase()}';
  }
  if (lower.startsWith('us.')) return 'us.${t.substring(3).toUpperCase()}';
  if (lower.startsWith('us') && RegExp(r'^[A-Za-z0-9._-]+$').hasMatch(t.substring(2)) && t.length > 2) {
    return 'us${t.substring(2).toUpperCase()}';
  }
  if (lower.startsWith('gl') && t.length > 2) return t;
  if (lower.startsWith('yh') && t.length > 2) return t;
  if (RegExp(r'^[A-Za-z]{1,6}([.-][A-Za-z])?$').hasMatch(t)) {
    return 'us${t.toUpperCase().replaceAll('-', '.')}';
  }
  return null;
}

ParseResult parseWatchlist(String text) {
  final out = <Security>[];
  final seen = <String>{};
  var skipped = 0;
  for (final line in text.split(RegExp(r'[\r\n]+'))) {
    final l = line.trim();
    if (l.isEmpty || l.startsWith('#')) continue;
    final m = RegExp(r'^([^,，\t;；\s]+)[,，\t;；\s]*(.*)$').firstMatch(l);
    final code = m == null ? null : _normalizeCode(m.group(1)!);
    if (code == null) {
      skipped++;
      continue;
    }
    final name = (m!.group(2) ?? '').trim();
    if (seen.add(code)) {
      out.add(Security(code: code, name: name.isEmpty ? code : name));
    }
  }
  return ParseResult(out, skipped);
}

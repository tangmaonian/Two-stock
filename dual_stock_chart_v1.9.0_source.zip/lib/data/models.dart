/// Plain data models shared by the data layer, chart layer and UI.

class Security {
  const Security({required this.code, required this.name});

  /// Tencent-style code: sh600519, sz000001, sh000001 (index), usAAPL.OQ ...
  final String code;
  final String name;

  bool get isUs => code.startsWith('us');
  bool get isHk => code.startsWith('hk');
  /// Global indices served by Eastmoney, stored as "gl<secid>", e.g.
  /// "gl100.N225". The old "yh<symbol>" form is still accepted for imported
  /// watchlists and is mapped to Eastmoney in the data source.
  bool get isGlobal => code.startsWith('gl') || code.startsWith('yh');
  bool get isCn => code.isNotEmpty && !isUs && !isHk && !isGlobal;

  /// The empty "no overlay" selection (see [kNoOverlay]).
  bool get isNone => code.isEmpty;

  String get marketLabel =>
      isUs ? '美股' : (isHk ? '港股' : (isGlobal ? '全球指数' : 'A股'));

  String get shortCode {
    if (isGlobal) {
      final secid = code.substring(2);
      final dot = secid.indexOf('.');
      return dot >= 0 ? secid.substring(dot + 1) : secid;
    }
    var r = code.replaceFirst(RegExp(r'^(sh|sz|bj|hk)'), '');
    if (r.startsWith('us')) r = r.substring(2);
    if (r.startsWith('.')) r = r.substring(1);
    return r;
  }
}

/// One daily bar. [date] is "yyyy-MM-dd" exactly as delivered by the source.
class Bar {
  const Bar(this.date, this.close);
  final String date;
  final double close;
}

class PriceSeries {
  PriceSeries({
    required this.security,
    required this.bars,
    required this.fetchedAt,
    required this.source,
    required this.adjustment,
    required this.decimals,
    this.fromCache = false,
  });

  final Security security;
  final List<Bar> bars;

  /// True when loaded from the on-device store (not fetched just now);
  /// [fetchedAt] is then the time it was saved.
  final bool fromCache;
  final DateTime fetchedAt;
  final String source;

  /// '不复权' or '前复权' - what the prices really are.
  final String adjustment;

  /// Number of decimals to show for this security's prices.
  final int decimals;

  String get lastDate => bars.last.date;
}

/// A live / delayed snapshot price. [asOf] is the timestamp reported by the
/// source (exchange time), NOT the time we fetched it.
/// US Eastern offset from UTC (hours) for a US wall-clock time.
int usEasternOffset(DateTime wall) {
  DateTime nthSunday(int month, int n) {
    var d = DateTime.utc(wall.year, month, 1);
    while (d.weekday != DateTime.sunday) {
      d = d.add(const Duration(days: 1));
    }
    return d.add(Duration(days: 7 * (n - 1)));
  }

  final start = nthSunday(3, 2).add(const Duration(hours: 2));
  final end = nthSunday(11, 1).add(const Duration(hours: 2));
  final w = DateTime.utc(
      wall.year, wall.month, wall.day, wall.hour, wall.minute, wall.second);
  final dst = !w.isBefore(start) && w.isBefore(end);
  return dst ? -4 : -5;
}

class Quote {
  Quote({
    required this.security,
    required this.price,
    required this.prevClose,
    required this.asOf,
    required this.fetchedAt,
    required this.source,
    this.usEastern = false,
  });
  final Security security;
  final bool usEastern; // asOf is US Eastern wall-clock time
  final double price;
  final double? prevClose;
  final String asOf; // "yyyy-MM-dd HH:mm:ss" as reported, may be date only
  final DateTime fetchedAt;
  final String source;

  String get asOfDate => asOf.length >= 10 ? asOf.substring(0, 10) : asOf;

  /// Age of the quote in minutes relative to now, or null if unparseable.
  int? ageMinutes() {
    final t = DateTime.tryParse(asOf.replaceFirst(' ', 'T'));
    if (t == null || asOf.length < 16) return null;
    // China/HK time is UTC+8; US quotes carry US Eastern time.
    final offset = usEastern ? usEasternOffset(t) : 8;
    final utc = DateTime.utc(t.year, t.month, t.day, t.hour, t.minute, t.second)
        .subtract(Duration(hours: offset));
    return DateTime.now().toUtc().difference(utc).inMinutes;
  }
}

class DataException implements Exception {
  DataException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// The blank choice for the overlay slot: nothing is overlaid.
const Security kNoOverlay = Security(code: '', name: '无叠加');

/// Default list shown in the search sheet (code first, name second).
/// All entries are served by Eastmoney in mainland China.
const List<Security> kPresets = [
  // A-share indices
  Security(code: 'sh000001', name: '上证指数'),
  Security(code: 'sz399001', name: '深证成指'),
  Security(code: 'sz399006', name: '创业板指'),
  Security(code: 'sh000300', name: '沪深300'),
  Security(code: 'sh000688', name: '科创50'),
  // HK indices
  Security(code: 'hkHSI', name: '恒生指数'),
  Security(code: 'hkHSTECH', name: '恒生科技指数'),
  // US indices
  Security(code: 'us.INX', name: '标普500'),
  Security(code: 'us.IXIC', name: '纳斯达克综合'),
  Security(code: 'us.DJI', name: '道琼斯'),
  // Global indices (Eastmoney secid: gl + secid)
  Security(code: 'gl100.N225', name: '日经225（日本）'),
  Security(code: 'gl100.TWII', name: '台湾加权指数'),
  Security(code: 'gl100.KS11', name: '韩国综合指数'),
  Security(code: 'gl100.GDAXI', name: '德国DAX30'),
  Security(code: 'gl100.FCHI', name: '法国CAC40'),
  Security(code: 'gl100.SENSEX', name: '印度SENSEX'),
  Security(code: 'gl100.RTS', name: '俄罗斯RTS'),
  Security(code: 'gl100.SET', name: '泰国SET'),
  Security(code: 'gl100.VNINDEX', name: '越南VN-Index'),
  Security(code: 'gl100.BVSP', name: '巴西圣保罗BOVESPA'),
  // Popular A-share stocks
  Security(code: 'sh600519', name: '贵州茅台'),
  Security(code: 'sz000858', name: '五粮液'),
  Security(code: 'sh601318', name: '中国平安'),
  Security(code: 'sh600036', name: '招商银行'),
  Security(code: 'sz300750', name: '宁德时代'),
  Security(code: 'sz002594', name: '比亚迪'),
  Security(code: 'sh601899', name: '紫金矿业'),
  Security(code: 'sh600900', name: '长江电力'),
  Security(code: 'sz002415', name: '海康威视'),
  Security(code: 'sh601012', name: '隆基绿能'),
  // Popular HK stocks
  Security(code: 'hk00700', name: '腾讯控股'),
  Security(code: 'hk09988', name: '阿里巴巴-W'),
  Security(code: 'hk03690', name: '美团-W'),
  Security(code: 'hk01810', name: '小米集团-W'),
  Security(code: 'hk00941', name: '中国移动'),
  Security(code: 'hk09618', name: '京东集团-SW'),
  Security(code: 'hk02318', name: '中国平安'),
  Security(code: 'hk01299', name: '友邦保险'),
  // Popular US stocks
  Security(code: 'usAAPL', name: '苹果'),
  Security(code: 'usMSFT', name: '微软'),
  Security(code: 'usNVDA', name: '英伟达'),
  Security(code: 'usTSLA', name: '特斯拉'),
  Security(code: 'usAMZN', name: '亚马逊'),
  Security(code: 'usGOOGL', name: '谷歌-A'),
  Security(code: 'usMETA', name: 'Meta平台'),
  Security(code: 'usBABA', name: '阿里巴巴'),
];
